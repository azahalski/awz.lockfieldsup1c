<?php
$arModuleVersion = array(
	"VERSION" => "1.0.1",
	"VERSION_DATE" => "2026-06-29 09:32:40"
);
?>