<?php
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_before.php");

use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Config\Configuration;
use Bitrix\Main\Loader;
use Bitrix\Main\Application;
use Bitrix\Main\UI\Extension;
use Awz\Lockfieldsup1c\Access\AccessController;
use Awz\Lockfieldsup1c\IblockLockHandler;

Loc::loadMessages(__FILE__);
global $APPLICATION;
$module_id = "awz.lockfieldsup1c";
if(!Loader::includeModule($module_id)) return;
Extension::load('ui.sidepanel-content');
$request = Application::getInstance()->getContext()->getRequest();
$APPLICATION->SetTitle(Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_TITLE'));

if($request->get('IFRAME_TYPE')==='SIDE_SLIDER'){
    require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_after.php");
    require_once('lib/access/include/moduleright.php');
    CMain::finalActions();
    die();
}

if(!AccessController::isViewSettings())
    $APPLICATION->AuthForm(Loc::getMessage("ACCESS_DENIED"));
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_after.php");

// Обработка AJAX-запросов
if ($request->get('ajax_action')) {
    \Awz\Lockfieldsup1c\Api\Controller::processAjax();
    return;
}

if ($request->getRequestMethod()==='POST' && AccessController::isEditSettings() && $request->get('Update') && check_bitrix_sessid())
{
    // Сохранение настроек защиты полей
    $lockedProperties = [];
    $iblockIds = $request->get('lock_iblock_id');
    $propCodes = $request->get('lock_property_code');
    $lockTypes = $request->get('lock_type');
    $requestParamsArr = $request->get('lock_request_params');
    $userIdsArr = $request->get('lock_user_ids');
    $enabled = $request->get('module_enabled') === 'Y';

    if (is_array($iblockIds) && is_array($propCodes) && is_array($lockTypes)) {
        foreach ($iblockIds as $index => $iblockId) {
            $iblockId = (int)$iblockId;
            $propCode = $propCodes[$index] ?? '';
            $lockType = $lockTypes[$index] ?? 'all';
            $requestParams = $requestParamsArr[$index] ?? 'type=catalog&mode=import';
            $userIds = $userIdsArr[$index] ?? '';

            if ($iblockId > 0 && !empty($propCode)) {
                $key = $iblockId . '_' . $propCode;
                $lockedProperties[$key] = [
                    'iblock_id' => $iblockId,
                    'property_code' => $propCode,
                    'lock_type' => $lockType,
                    'request_params' => $requestParams,
                    'user_ids' => $userIds
                ];
            }
        }
    }

    IblockLockHandler::saveLockedProperties($lockedProperties);
    
    // Сохранение опции включения модуля
    Option::set($module_id, 'enabled', $enabled ? 'Y' : 'N', '');

    // Сохранение опции журналирования в журнал событий (fallback-лог)
    Option::set($module_id, 'ENABLE_JOURNAL_LOG', $request->get('enable_journal_log') === 'Y' ? 'Y' : 'N', '');
    //\Awz\Lockfieldsup1c\Logger::$journalEnabled = null;

    // Включение PSR-лога (файл с ротацией 20Мб) через .settings.php
    // constructorParams - только массив (без closure), иначе var_export при сохранении сломает файл
    $psrEnabled = $request->get('enable_psr_log') === 'Y';
    try {
        $config = Configuration::getInstance();
        $loggersValue = (array)($config->get('loggers') ?? []);
        if (isset($loggersValue['value']) && is_array($loggersValue['value'])) {
            $loggersValue = $loggersValue['value'];
        }
        if ($psrEnabled) {
            $loggersValue['awz.lockfieldsup1c'] = [
                'className' => '\Bitrix\Main\Diag\FileLogger',
                'constructorParams' => [$_SERVER['DOCUMENT_ROOT'].'/local/logs/awz.lockfieldsup1c.log', 20*1024*1024],
                'level' => \Psr\Log\LogLevel::DEBUG
            ];
        } else {
            unset($loggersValue['awz.lockfieldsup1c']);
        }
        // add() сам оборачивает в ['value'=>..., 'readonly'=>...], передаем только массив логгеров
        $config['loggers'] = $loggersValue;
        $config->saveConfiguration();
    } catch (\Throwable $e) {
    }
}

// Получаем текущие настройки
$currentLockedProps = IblockLockHandler::getLockedProperties();

try {
    $loggersCfg = (array)(Configuration::getInstance()->get('loggers') ?? []);
    //echo'<pre>';print_r($loggersCfg);echo'</pre>';
    $currentPsrLogger = is_array($loggersCfg) && isset($loggersCfg['awz.lockfieldsup1c']);
} catch (\Throwable $e) {
    $currentPsrLogger = false;
}

$aTabs = array();

$aTabs[] = array(
    "DIV" => "edit2",
    "TAB" => Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_SECT3'),
    "ICON" => "vote_settings",
    "TITLE" => Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_SECT3')
);

$saveUrl = $APPLICATION->GetCurPage(false).'?mid='.htmlspecialcharsEx($module_id).'&lang='.LANGUAGE_ID.'&mid_menu=1';
$tabControl = new CAdminTabControl("tabControl", $aTabs);
$tabControl->Begin();
?>
    <style>.adm-workarea option:checked {background-color: rgb(206, 206, 206);}</style>
    <form method="POST" action="<?=$saveUrl?>" id="FORMACTION">
        <?=bitrix_sessid_post()?>
        <?
        $tabControl->BeginNextTab();
        Extension::load("ui.alerts");
        ?>

        <tr>
            <td colspan="2" style="padding-bottom:1rem;">
                <label>
                    <input type="checkbox" name="module_enabled" value="Y" <?=Option::get($module_id, 'enabled', 'Y') === 'Y' ? 'checked' : ''?>>
                    <?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_MODULE_ENABLED')?>
                </label>
            </td>
        </tr>

        <tr>
            <td colspan="2" style="padding-bottom:1rem;">
                <label>
                    <input type="checkbox" name="enable_journal_log" value="Y" <?=Option::get($module_id, 'ENABLE_JOURNAL_LOG', 'N') === 'Y' ? 'checked' : ''?>>
                    <?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_ENABLE_JOURNAL_LOG')?>
                </label>
                <div style="padding:0.5rem 0;">
                    <?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_JOURNAL_LOG_DESC')?>
                    <br>
                    <a href="/bitrix/admin/event_log.php?set_filter=Y&find_module_id=<?=$module_id?>&find_type=audit_type&find_audit_type_str=AWZ_LOCKFIELDSUP1C" target="_blank">
                        <?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_JOURNAL_LOG_LINK')?>
                    </a>
                </div>
            </td>
        </tr>

        <tr>
            <td colspan="2" style="padding-bottom:1rem;">
                <label>
                    <input type="checkbox" name="enable_psr_log" value="Y" <?=isset($currentPsrLogger) && $currentPsrLogger ? 'checked' : ''?>>
                    <?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_ENABLE_PSR_LOG')?>
                </label>
                <div style="padding:0.5rem 0;">
                    <?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_PSR_LOG_DESC')?>
                </div>
            </td>
        </tr>

        <tr>
            <td colspan="2">
                <div style="padding:0.5rem 0;display:block;clear:both;">
                <div class="ui-alert ui-alert-info">
                    <span class="ui-alert-message">
                        <?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_LOCK_FIELDS_DESC')?>
                    </span>
                </div>
                </div>
                <div style="padding:1rem 0;display:block;clear:both;">
                    <b><?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_REQUEST_PARAMS')?></b>
                    <br>
                    <?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_REQUEST_PARAMS_DESC')?>
                </div>
                <div style="padding:1rem 0;display:block;clear:both;">
                    <b><?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_USER_IDS')?></b>
                    <br>
                    <?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_USER_IDS_DESC')?>
                </div>
            </td>
        </tr>



        <tr>
            <td colspan="2">
                <table class="adm-detail-content-table" id="lock-fields-table">
                    <thead>
                        <tr>
                            <th style="text-align:left;padding-bottom:0.5rem;"><?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_LOCK_IBLOCK')?></th>
                            <th style="text-align:left;padding-bottom:0.5rem;"><?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_LOCK_PROPERTY')?></th>
                            <th style="text-align:left;padding-bottom:0.5rem;"><?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_LOCK_TYPE')?></th>
                            <th style="text-align:left;padding-bottom:0.5rem;"><?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_REQUEST_PARAMS')?></th>
                            <th style="text-align:left;padding-bottom:0.5rem;"><?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_USER_IDS')?></th>
                            <th style="text-align:left;padding-bottom:0.5rem;"></th>
                        </tr>
                    </thead>
                    <tbody id="lock-fields-rows">
                        <?if(!empty($currentLockedProps)):?>
                            <?foreach($currentLockedProps as $key => $config):?>
                                <tr class="lock-field-row">
                                    <td>
                                        <select name="lock_iblock_id[]" class="lock-iblock-select" onchange="loadProperties(this)" style="max-width:160px;">
                                            <option value=""><?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_LOCK_SELECT_IBLOCK')?></option>
                                            <?foreach(IblockLockHandler::getIblocks() as $ib):?>
                                                <option value="<?=$ib['ID']?>" <?=$ib['ID'] == $config['iblock_id'] ? 'selected' : ''?>>
                                                    [<?=$ib['ID']?>] <?=htmlspecialcharsEx($ib['NAME'])?>
                                                </option>
                                            <?endforeach;?>
                                        </select>
                                    </td>
                                    <td>
                                        <select name="lock_property_code[]" class="lock-property-select" style="max-width:200px;">
                                            <option value=""><?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_LOCK_SELECT_PROPERTY')?></option>
                                            <?
                                            $properties = IblockLockHandler::getIblockProperties($config['iblock_id']);
                                            ?>
                                            <?foreach($properties as $prop):?>
                                                <option value="<?=$prop['CODE']?>" <?=$prop['CODE'] == $config['property_code'] ? 'selected' : ''?>>
                                                    [<?=$prop['CODE']?>] <?=htmlspecialcharsEx($prop['NAME'])?>
                                                </option>
                                            <?endforeach;?>
                                        </select>
                                    </td>
                                    <td>
                                        <select name="lock_type[]">
                                            <option value="all" <?=$config['lock_type'] == 'all' ? 'selected' : ''?>>
                                                <?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_LOCK_TYPE_ALL')?>
                                            </option>
                                            <?if(false){?>
                                            <option value="empty" <?=$config['lock_type'] == 'empty' ? 'selected' : ''?>>
                                                <?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_LOCK_TYPE_EMPTY')?>
                                            </option>
                                            <?}?>
                                        </select>
                                    </td>
                                    <td>
                                        <input type="text" name="lock_request_params[]" value="<?=htmlspecialcharsEx($config['request_params'] ?? 'type=catalog&mode=import')?>" style="" placeholder="type=catalog&mode=import">
                                    </td>
                                    <td>
                                        <input type="text" name="lock_user_ids[]" value="<?=htmlspecialcharsEx($config['user_ids'] ?? '')?>" style="" placeholder="">
                                    </td>
                                    <td>
                                        <button type="button" class="adm-btn" onclick="removeLockRow(this)" style="margin-left:1rem;">
                                            <?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_LOCK_DELETE')?>
                                        </button>
                                    </td>
                                </tr>
                            <?endforeach;?>
                        <?endif;?>
                    </tbody>
                </table>
                <br>
                <a class="" href="#" onclick="addLockRow();return false;">
                    <?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_LOCK_ADD')?>
                </a>
            </td>
        </tr>

        <?$tabControl->Buttons();?>
        <input <?if (!AccessController::isEditSettings()) echo "disabled" ?> type="submit" class="adm-btn-green" name="Update" value="<?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_L_BTN_SAVE')?>" />
        <input type="hidden" name="Update" value="Y" />
        <?if(AccessController::isViewRight()){?>
            <button class="adm-header-btn adm-security-btn" onclick="BX.SidePanel.Instance.open('<?=$saveUrl?>');return false;">
                <?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_SECT2')?>
            </button>
        <?}?>
        <?$tabControl->End();?>
    </form>

    <script>
    function addLockRow() {
        var tbody = document.getElementById('lock-fields-rows');
        var newRow = document.createElement('tr');
        newRow.className = 'lock-field-row';
        newRow.innerHTML = `
            <td>
                <select name="lock_iblock_id[]" class="lock-iblock-select" onchange="loadProperties(this)" style="max-width:160px;">
                    <option value=""><?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_LOCK_SELECT_IBLOCK')?></option>
                    <?foreach(IblockLockHandler::getIblocks() as $ib):?>
                        <option value="<?=(int)$ib['ID']?>">
                            [<?=(int)$ib['ID']?>] <?=htmlspecialcharsEx($ib['NAME'])?>
                        </option>
                    <?endforeach;?>
                </select>
            </td>
            <td>
                <select name="lock_property_code[]" class="lock-property-select" style="max-width:200px;">
                    <option value=""><?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_LOCK_SELECT_PROPERTY')?></option>
                </select>
            </td>
            <td>
                <select name="lock_type[]">
                    <option value="all"><?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_LOCK_TYPE_ALL')?></option>
                    <?if(false){?><option value="empty"><?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_LOCK_TYPE_EMPTY')?></option><?}?>
                </select>
            </td>
            <td>
                <input type="text" name="lock_request_params[]" value="type=catalog&mode=import" placeholder="type=catalog&mode=import">
            </td>
            <td>
                <input type="text" name="lock_user_ids[]" value="" placeholder="">
            </td>
            <td>
                <button type="button" class="adm-btn" onclick="removeLockRow(this)" style="margin-left:1rem;">
                    <?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_LOCK_DELETE')?>
                </button>
            </td>
        `;
        tbody.appendChild(newRow);
    }

    function removeLockRow(btn) {
        var row = btn.closest('tr');
        if (row) {
            row.parentNode.removeChild(row);
        }
    }

    function loadProperties(select) {
        var iblockId = select.value;
        var row = select.closest('tr');
        var propSelect = row.querySelector('.lock-property-select');

        // Очищаем текущие опции
        propSelect.innerHTML = '<option value=""><?=Loc::getMessage('AWZ_LOCKFIELDSUP1C_OPT_LOCK_SELECT_PROPERTY')?></option>';

        if (!iblockId) {
            return;
        }

        // AJAX запрос для получения свойств инфоблока через BX.ajax.runAction
        BX.ajax.runAction('awz:lockfieldsup1c.api.controller.getProperties', {
            data: {
                iblockId: iblockId
            }
        }).then(function(response) {
            if (response.data && response.data) {
                response.data.forEach(function(prop) {
                    var option = document.createElement('option');
                    option.value = prop.CODE;
                    option.textContent = '[' + prop.CODE + '] ' + prop.NAME;
                    propSelect.appendChild(option);
                });
            }
        }).catch(function(error) {
            // Отображаем ошибку в интерфейсе
            try{
                var errorMessage = error.errors[0].message;
            }catch (e) {
                var errorMessage = 'Ошибка при загрузке свойств';
            }

            var alertDiv = document.createElement('div');
            alertDiv.className = 'ui-alert ui-alert-danger';
            alertDiv.style.marginBottom = '10px';
            alertDiv.innerHTML = '<span class="ui-alert-message">' + errorMessage + '</span>';
            
            // Добавляем alert перед таблицей
            var table = document.getElementById('lock-fields-table');
            if (table) {
                table.parentNode.insertBefore(alertDiv, table);
            } else {
                console.error('Error loading properties:', error);
            }
        });
    }
    </script>
<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/epilog_admin.php");
